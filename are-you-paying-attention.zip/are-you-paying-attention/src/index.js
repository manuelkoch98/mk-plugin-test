wp.blocks.registerBlockType("ourplugin/text-lottie", {
    title: "Text + Lottie",
    icon: "text",
    category: "common",
    attributes: {
        headline: {type: "string"},
        content: {type: "string"},
        url: {type: "string"}
    },
    edit: function(props) {
        function updateHeadline(event) {
            props.setAttributes({headline: event.target.value})
        }

        function updateContent(event) {
            props.setAttributes({content: event.target.value})
        }

        function updateURL(event) {
            props.setAttributes({url: event.target.value})
        }

        return (
            <div>
                <h3>Text + Lottie</h3>
                {/* Überschrift */}
                <input type="text" placeholder="Headline" value={props.attributes.headline} onChange={updateHeadline}/>
                {/* Content */}
                <textarea placeholder="Content" rows="10" cols="100" value={props.attributes.content} onChange={updateContent}></textarea>
                {/* URL Lottie */}
                <input type="url" placeholder="Hier Lottie URL platzieren" size="50" value={props.attributes.url} onChange={updateURL}/>
                <button class="components-button editor-post-publish-panel__toggle editor-post-publish-button__button is-primary" src="https://lottiefiles.com/">lottiefiles.com durchsuchen</button>
            </div>
        )
    },
    save: function(props) {
        return null
    }
})
